# Biclustering Analysis of Functionals via Penalized Fusion

This is a sample code for Biclustering project "Biclustering Analysis of Functionals via Penalized Fusion".

# Getting Started

## Prerequisites
The sample code is built under software R (https://www.r-project.org). Please have the following packages installed in your machine.
install.packages("plyr");

install.packages(fda);#bspline basis

install.packages(Matrix);

install.packages(igraph);


## Running the tests
We provide a sample setting of Example 1 for our paper in Sample.R. Please run Sample.R to test the biclustering algorithm. 


