rm(list=ls())
library(MASS)
library(plyr)
library(fda)
library(igraph)


##################################################################################################
#################################    The settings of Example 1     ###############################
##################################################################################################



###########################  Part1: create design matrix(B spline basis),   ###########################
###########################        response vector and difference matrix    #########################

set.seed(10)

#sample size and feature size
n <- 30
q <- 9
#max number of repeated measurements
TT <- 10;

##labels of class
class1 <- 1:10
class2 <- 11:20
class3 <- 21:30

##time points for each curve
t <- seq(0, 1, length.out = TT)

c1_1 <- cos(2*pi*t)
c1_2 <- 1+sin(2*pi*t)
c1_3 <- 2*(sin(2*pi*t)+cos(2*pi*t))

c2_1 <- 1-2*exp(-6*t)
c2_2 <- 2*t^2
c2_3 <- 1+t^3

c3_1 <- -1.5*t
c3_2 <- t+1
c3_3 <- 2*sqrt(t)+1

sigma <- 0.6

oridata_list <- vector(mode = "list", length = n)

for (i in 1:n) {
  
  if (i %in% class1) oridata_list[[i]] <- list(c1_1 + rnorm(TT,0,sigma), c1_1 + rnorm(TT,0,sigma),
                                               c1_1 + rnorm(TT,0,sigma), c1_2 + rnorm(TT,0,sigma),
                                               c1_2 + rnorm(TT,0,sigma), c1_2 + rnorm(TT,0,sigma),
                                               c1_3 + rnorm(TT,0,sigma), c1_3 + rnorm(TT,0,sigma),
                                               c1_3 + rnorm(TT,0,sigma))
  
  if (i %in% class2) oridata_list[[i]] <- list(c2_1 + rnorm(TT,0,sigma), c2_1 + rnorm(TT,0,sigma),
                                               c2_1 + rnorm(TT,0,sigma), c2_2 + rnorm(TT,0,sigma),
                                               c2_2 + rnorm(TT,0,sigma), c2_2 + rnorm(TT,0,sigma),
                                               c2_3 + rnorm(TT,0,sigma), c2_3 + rnorm(TT,0,sigma),
                                               c2_3 + rnorm(TT,0,sigma))
  
  if (i %in% class3) oridata_list[[i]] <- list(c3_1 + rnorm(TT,0,sigma), c3_1 + rnorm(TT,0,sigma),
                                               c3_1 + rnorm(TT,0,sigma), c3_2 + rnorm(TT,0,sigma),
                                               c3_2 + rnorm(TT,0,sigma), c3_2 + rnorm(TT,0,sigma),
                                               c3_3 + rnorm(TT,0,sigma), c3_3 + rnorm(TT,0,sigma),
                                               c3_3 + rnorm(TT,0,sigma))
  
}

##generate a data list to contain the time information in each sample list
times <- vector(mode = "list", length = n)
for (i in 1:n) {
  times[[i]] <- list(t,t,t,t,t,t,t,t,t)
}

##generate a sample list to contain the all sample information in each dataframe
sample_list <- vector(mode = "list", length = n)
id <- matrix(0, nrow = n, ncol = q)
for (i in 1:n) {
  for (j in 1:q) {
    id[i,j] <- length(oridata_list[[i]][[j]])
  }
  sample_list[[i]] <- data.frame(id = rep(1:q, id[i,]), time = unlist(times[[i]]), y = unlist(oridata_list[[i]]))
}

##generate a design matrix for  sample basis

timerange <- seq(0,1,length.out = TT)
nknots <- 3
order <- 3
p <- nknots + order


data_list <- vector(mode = "list", length = n)
for (i in 1:n) {
  data_list[[i]] <- vector(mode = "list", length = q)
  basis <- dlply(sample_list[[i]], .(id), function(xx) bsplineS(xx$time, knots_eq3(timerange, k = order, m = nknots), norder = order))
  
  for (j in 1:q) {
    data_list[[i]][[j]] <- basis[[j]]
  }
}


##generate response vector
Y_list <- vector(mode = "list", length = n)
for (i in 1:n) {
  Y_list[[i]] <- vector(mode = "list", length = q)
  for (j in 1:q) {
    Y_list[[i]][[j]] <- sample_list[[i]]$y[sample_list[[i]]$id == j]
  }
}

###construct missing samples under balanced data

miss_percent <- 0.3
subgroup_sam <- 3
subgroup_fea <- 3
cluster_struc_sam <- c(10,10,10)
cluster_struc_fea <- c(3,3,3)

cluster_gap_sam <- c(0,10,20)
cluster_gap_fea <- c(0,3,6)

miss_meas <- 0.2

for (i in 1:subgroup_sam) {
  for (j in 1:subgroup_fea) {
    num_elem <- cluster_struc_sam[i] * cluster_struc_fea[j]
    num_miss <- ceiling(num_elem * miss_percent) 
    id1 <- sample(1:num_elem, num_miss)
    id_loac <- matrix(0, nrow = num_miss, ncol = 2)
    mat <- matrix(1:num_elem, nrow = cluster_struc_sam[i], ncol = cluster_struc_fea[j])
    for (l in 1:length(id1)) {
      id_loac[l,] <- as.vector(which(mat == id1[l], arr.ind = TRUE))
    }
    
    for (l in 1:length(id1)) {
      i1 <- id_loac[l,1]
      j1 <- id_loac[l,2]
      id2 <- sort(sample(1:TT, (1-miss_meas)*TT))  
      times[[i1 + cluster_gap_sam[i]]][[j1 + cluster_gap_fea[j]]] <- t[id2]
      basis_new <- bsplineS(t[id2], knots_eq3(timerange, k = order, m = nknots), norder = order)
      data_list[[i1 + cluster_gap_sam[i]]][[j1 + cluster_gap_fea[j]]] <- basis_new
      Y_list[[i1 + cluster_gap_sam[i]]][[j1 + cluster_gap_fea[j]]] <- Y_list[[i1 + cluster_gap_sam[i]]][[j1 + cluster_gap_fea[j]]][id2]
    }
    
  }
}

##generate a difference matrix
C <- matrix(0, nrow = nknots+order-2, ncol = nknots+order)
for (j in 1:(nknots+order-2)){
  d_j <- c(rep(0,j-1),1,-2,1,rep(0,(nknots+order)-3-(j-1)))
  e_j <- c(rep(0,j-1), 1 ,rep(0,(nknots+order)-3-(j-1)))
  C <- C + e_j %*% t(d_j)
}

D_d = t(C)%*%C;


###################################  Part2: ADMM algorithm  ###################################

gamma1 <- 0.023
gamma2 <- 3

Beta_ini <- Beta_ini_cal(data_list, Y_list, D_d, n, q, p, gamma1 = gamma1)

system.time(inv_UTY_result <- inv_UTY_cal(data_list, Y_list, D_d, n, q, p, gamma1 = gamma1, theta = 1)) 


system.time(result <- biclustr_admm(inv_UTY_result, data_list, Y_list, D_d, Beta_ini, n, q, p, gamma1 = gamma1, 
                                    gamma2 = gamma2, theta = 1, tau = 3, max_iter = 500, 
                                    eps_abs = 1e-3, eps_rel = 1e-3)) 



##Row clustering membership
Ad_final_sam <- create_adjacency(result$V1, n);
G_final_sam <- graph.adjacency(Ad_final_sam, mode = 'upper')
cls_final_sam <- components(G_final_sam);


##Column clustering membership
Ad_final_fea <- create_adjacency(result$V2, q);
G_final_fea <- graph.adjacency(Ad_final_fea, mode = 'upper')
cls_final_fea <- components(G_final_fea);




