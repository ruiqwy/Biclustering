


##This function is used to generate the inverse part of the solution to beta

inv_UTY_cal <- function(oridata_list, Y_list, D_d, n, q, p, gamma1, theta){
  
  UTU_list <- vector(mode = "list", length = n*q)
  UTY_list <- vector(mode = "list", length = n*q)
  
  for (i in 1:n) {
    for (j in 1:q) {
      UTU_list[[(i-1)*q + j]] <- t(oridata_list[[i]][[j]]) %*% oridata_list[[i]][[j]]
      UTY_list[[(i-1)*q + j]] <- as.numeric(t(oridata_list[[i]][[j]]) %*% Y_list[[i]][[j]])
    }
  }
  
  UTU_mat <- as.matrix(bdiag(UTU_list))
  UTY_vec <- do.call("c", UTY_list)
  
  
  
  diagM <- kronecker(diag(1, n*q), D_d)
  
  term1 <- n*diag(1, n) - matrix(1, nrow = n, ncol = n)
  A1TA1 <- kronecker(term1, diag(1, p*q))
  
  term2 <- q*diag(1, q) - matrix(1, nrow = q, ncol = q)
  A2TA2 <- kronecker(diag(1, n), kronecker(term2, diag(1, p)))
  
  #tt <- UTU_mat + gamma1*diagM + theta*A1TA1 + theta*A2TA2
  inv <- solve(UTU_mat + gamma1*diagM + theta*A1TA1 + theta*A2TA2)
  
  return(list(inv = inv, UTY = UTY_vec))
  #return(tt)
}


##These functions are used to update the corresponding terms in ADMM algorithm
update_Beta <- function(inv, UTY, index1, index2, V1, V2, Lambda1, Lambda2, n, q, p, theta){
  
  V1_tilde <- V1 + Lambda1/theta
  
  A1TV1 <- matrix(0, nrow = p*q, ncol = n)
  A1TV1[,1] <- apply(as.matrix(V1_tilde[, index1[,1] == 1]), MARGIN = 1, sum)  
  for (k in 2:(n-1)) {
    A1TV1[,k] <- apply(as.matrix(V1_tilde[, index1[,1] == k]), MARGIN = 1, sum) -
      apply(as.matrix(V1_tilde[, index1[,2] == k]), MARGIN = 1, sum)
  }
  A1TV1[,n] <- - apply(as.matrix(V1_tilde[, index1[,2] == n]), MARGIN = 1, sum)
  A1TV1_vec <- as.vector(A1TV1)
  
  V2_tilde <- V2 + Lambda2/theta
  
  A2TV2_list <- vector(mode = "list", length = n)
  
  for (i in 1:n) {
    A2TV2_list[[i]] <- matrix(0, nrow = p, ncol = q)
    A2TV2_list[[i]][,1] <- apply(as.matrix(V2_tilde[(1+(i-1)*p):(i*p), index2[,1] == 1]), MARGIN = 1, sum)
    
    for (k in 2:(q-1)) {
      A2TV2_list[[i]][,k] <- apply(as.matrix(V2_tilde[(1+(i-1)*p):(i*p), index2[,1] == k]), MARGIN = 1, sum) -
        apply(as.matrix(V2_tilde[(1+(i-1)*p):(i*p), index2[,2] == k]), MARGIN = 1, sum)
    }
    A2TV2_list[[i]][,q] <- -apply(as.matrix(V2_tilde[(1+(i-1)*p):(i*p), index2[,2] == q]), MARGIN = 1, sum)
    A2TV2_list[[i]] <- as.vector(A2TV2_list[[i]])
  }
  
  A2TV2_vec <- do.call("c", A2TV2_list)
  
  Beta <- as.numeric(inv %*% (UTY + theta*A1TV1_vec + theta*A2TV2_vec)) 
  #print(Beta)
  
  
  
}

update_V1 <- function(Beta, Lambda1, index1, p, q, n, tau, theta, gamma2){
  
  m1 <- nrow(index1) 
  V1 <- matrix(0, nrow = p*q, ncol = m1)
  U1 <- matrix(0, nrow = p*q, ncol = m1)
  Beta_mat <- matrix(Beta, nrow = p*q, ncol = n)
  
  for (l in 1:m1) {
    i <- index1[l,1]
    j <- index1[l,2]
    U1[,l] <- Beta_mat[,i] - Beta_mat[,j] - Lambda1[,l]/theta
    if (sqrt(sum(U1[,l]^2)) >= tau*gamma2) V1[,l] <- U1[,l]
    else V1[,l] <- (tau*theta/(tau*theta-1)) * max(0, (1 - (gamma2/theta)/sqrt(sum(U1[,l]^2)))) * U1[,l]
  }
  
  return(V1)
}

update_V2 <- function(Beta, Lambda2, index2, p, q, n, tau, theta, gamma2){
  
  m2 <- nrow(index2) 
  V2 <- matrix(0, nrow = p*n, ncol = m2)
  U2 <- matrix(0, nrow = p*n, ncol = m2)
  Beta_mat <- matrix(Beta, nrow = p*q, ncol = n)
  Beta_newmat <- matrix(0, nrow = p*n, ncol = q)
  for (j in 1:q) {
    Beta_newmat[,j] <- as.vector(Beta_mat[(1+(j-1)*p):(j*p),])
  }
  
  for (l in 1:m2) {
    i <- index2[l,1]
    j <- index2[l,2]
    U2[,l] <- Beta_newmat[,i] - Beta_newmat[,j] - Lambda2[,l]/theta
    if (sqrt(sum(U2[,l]^2)) >= sqrt(n/q)*tau*gamma2) V2[,l] <- U2[,l]
    else V2[,l] <- (tau*theta/(tau*theta-1)) * max(0, (1 - (sqrt(n/q)*gamma2/theta)/sqrt(sum(U2[,l]^2)))) * U2[,l]
  }
  
  return(V2)
}

update_Lambda1 <- function(Beta, V1, Lambda1_old, index1, theta, p, q, n){
  
  Beta_mat <- matrix(Beta, nrow = p*q, ncol = n)
  m1 <- nrow(index1)
  Lambda1 <- matrix(0, nrow = p*q, ncol = m1)
  for (l in 1:m1) {
    i <- index1[l,1]
    j <- index1[l,2]
    Lambda1[,l] <- Lambda1_old[,l] + theta*(V1[,l] - Beta_mat[,i] + Beta_mat[,j])
  }
  
  return(Lambda1)
}

update_Lambda2 <- function(Beta, V2, Lambda2_old, index2, theta, p, q, n){
  
  Beta_mat <- matrix(Beta, nrow = p*q, ncol = n)
  Beta_newmat <- matrix(0, nrow = p*n, ncol = q)
  for (j in 1:q) {
    Beta_newmat[,j] <- as.vector(Beta_mat[(1+(j-1)*p):(j*p),])
  }
  
  m2 <- nrow(index2)
  Lambda2 <- matrix(0, nrow = p*n, ncol = m2)
  for (l in 1:m2) {
    i <- index2[l,1]
    j <- index2[l,2]
    Lambda2[,l] <- Lambda2_old[,l] + theta*(V2[,l] - Beta_newmat[,i] + Beta_newmat[,j])
  }
  
  return(Lambda2)
}

##This function is used to generate the initial values of Beta
Beta_ini_cal <- function(oridata_list, Y_list, D_d, n, q, p, gamma1){
  Beta_list <- vector(mode = "list", length = n)
  for (i in 1:n) {
    Beta_list[[i]] <- vector(mode = "list", length = q)
    for (j in 1:q) {
      Beta_list[[i]][[j]] <- as.numeric(solve(t(oridata_list[[i]][[j]]) %*% oridata_list[[i]][[j]] + 
                                                gamma1*D_d) %*% t(oridata_list[[i]][[j]]) %*% Y_list[[i]][[j]])
    }
    
    Beta_list[[i]] <- do.call("c", Beta_list[[i]])
    
  }
  Beta_vec <- do.call("c", Beta_list)
  return(Beta_vec)
}


##This function is the main function for our algorithm
biclustr_admm <- function(inv_UTY_result, oridata_list, Y_list, D_d, Beta_ini, n, q, p, gamma1, gamma2, theta, 
                          tau, max_iter, eps_abs, eps_rel){
  
  
  index1 <- t(combn(n,2))
  index2 <- t(combn(q,2))
  m1 <- nrow(index1)
  m2 <- nrow(index2)
  
  Beta_old <- Beta_ini
  Beta_old_mat1 <- matrix(Beta_old, nrow = p*q, ncol = n)
  Beta_old_mat2 <- matrix(0, nrow = p*n, ncol = q)
  
  for (j in 1:q) {
    Beta_old_mat2[,j] <- as.vector(Beta_old_mat1[(1+(j-1)*p):(j*p),])
  }
  
  V1_old <- matrix(0, nrow = p*q, ncol = m1)
  V2_old <- matrix(0, nrow = p*n, ncol = m2)
  
  for (l in 1:m1) {
    i <- index1[l,1]
    j <- index1[l,2]
    V1_old[,l] <- Beta_old_mat1[,i] - Beta_old_mat1[,j]
  }
  
  for (l in 1:m2) {
    i <- index2[l,1]
    j <- index2[l,2]
    V2_old[,l] <- Beta_old_mat2[,i] - Beta_old_mat2[,j]
  }
  
  Lambda1_old <- matrix(0, nrow = p*q, ncol = m1)
  Lambda2_old <- matrix(0, nrow = p*n, ncol = m2)
  
  #inv_UTY_result <- inv_UTY_cal(oridata_list, Y_list, D_d, n, q, p, gamma1, theta)
  inv <- inv_UTY_result$inv
  UTY <- inv_UTY_result$UTY
  
  #print(V1_old)
  #print(V2_old)
  iter <- 1
  
  pri_resi1 <- 1
  pri_resi2 <- 1
  dual_resi1 <- 1
  dual_resi2 <- 1
  pri_tol1 <- 0
  pri_tol2 <- 0
  dual_tol1 <- 0
  dual_tol2 <- 0
  
  
  stop_con <- pri_resi1 > pri_tol1 | pri_resi2 > pri_tol2 | dual_resi1 > dual_tol1 | dual_resi2 > dual_tol2
  
  while (stop_con & iter <= max_iter) {
    
    Beta_new <- update_Beta(inv, UTY, index1, index2, V1_old, V2_old, Lambda1_old, 
                            Lambda2_old, n, q, p, theta)
    #print(Beta_new)
    V1_new <- update_V1(Beta_new, Lambda1_old, index1, p, q, n, tau, theta, gamma2)
    
    V2_new <- update_V2(Beta_new, Lambda2_old, index2, p, q, n, tau, theta, gamma2 = gamma2*0.5)
    
    Lambda1_new <- update_Lambda1(Beta_new, V1_new, Lambda1_old, index1, theta, p, q, n)
    
    Lambda2_new <- update_Lambda2(Beta_new, V2_new, Lambda2_old, index2, theta, p, q, n)
    
    Beta_new_mat1 <- matrix(Beta_new, nrow = p*q, ncol = n)
    Beta_new_mat2 <- matrix(0, nrow = p*n, ncol = q)
    
    for (j in 1:q) {
      Beta_new_mat2[,j] <- as.vector(Beta_new_mat1[(1+(j-1)*p):(j*p),])
    }
    
    pri_resi1_mat <- matrix(0, nrow = p*q, ncol = m1)
    pri_tol1_mat <- matrix(0, nrow = p*q, ncol = m1)
    for (l in 1:m1) {
      i <- index1[l,1]
      j <- index1[l,2]
      pri_resi1_mat[,l] <- Beta_new_mat1[,i] - Beta_new_mat1[,j] - V1_new[,l]
      pri_tol1_mat[,l] <- Beta_new_mat1[,i] - Beta_new_mat1[,j]
    }
    
    pri_resi1 <- sqrt(sum(pri_resi1_mat^2))
    pri_tol1 <- sqrt(m1*p*q)*eps_abs + eps_rel*max(sqrt(sum(pri_tol1_mat^2)), sqrt(sum(V1_new^2)))
    
    pri_resi2_mat <- matrix(0, nrow = p*n, ncol = m2)
    pri_tol2_mat <- matrix(0, nrow = p*n, ncol = m2)
    for (l in 1:m2) {
      i <- index2[l,1]
      j <- index2[l,2]
      pri_resi2_mat[,l] <- Beta_new_mat2[,i] - Beta_new_mat2[,j] - V2_new[,l]
      pri_tol2_mat[,l] <- Beta_new_mat2[,i] - Beta_new_mat2[,j]
    }
    
    pri_resi2 <- sqrt(sum(pri_resi2_mat^2))   
    pri_tol2 <- sqrt(m2*p*n)*eps_abs + eps_rel*max(sqrt(sum(pri_tol2_mat^2)), sqrt(sum(V2_new^2)))
    
    dual_resi1_mat <- matrix(0, nrow = p*q, ncol = n)
    dual_tol1_mat <- matrix(0, nrow = p*q, ncol = n)
    
    dual_resi1_mat[,1] <- apply(as.matrix(V1_new[, index1[,1] == 1]), MARGIN = 1, sum) - 
      apply(as.matrix(V1_old[, index1[,1] == 1]), MARGIN = 1, sum)
    dual_tol1_mat[,1] <- apply(as.matrix(Lambda1_new[, index1[,1] == 1]), MARGIN = 1, sum)
    
    for (k in 2:(n-1)) {
      dual_resi1_mat[,k] <- apply(as.matrix(V1_new[, index1[,1] == k]), MARGIN = 1, sum) -
        apply(as.matrix(V1_new[, index1[,2] == k]), MARGIN = 1, sum) - 
        apply(as.matrix(V1_old[, index1[,1] == k]), MARGIN = 1, sum) +
        apply(as.matrix(V1_old[, index1[,2] == k]), MARGIN = 1, sum)
      
      dual_tol1_mat[,k] <- apply(as.matrix(Lambda1_new[, index1[,1] == k]), MARGIN = 1, sum) -
        apply(as.matrix(Lambda1_new[, index1[,2] == k]), MARGIN = 1, sum)
    }
    
    dual_resi1_mat[,n] <- - apply(as.matrix(V1_new[, index1[,2] == n]), MARGIN = 1, sum) +
      apply(as.matrix(V1_old[, index1[,2] == n]), MARGIN = 1, sum)
    dual_tol1_mat[,n] <- - apply(as.matrix(Lambda1_new[, index1[,2] == n]), MARGIN = 1, sum)
    
    
    
    dual_resi1 <- sqrt(sum(dual_resi1_mat^2))
    dual_tol1 <- sqrt(n*p*q)*eps_abs + eps_rel*sqrt(sum(dual_tol1_mat^2))
    
    dual_resi2_list <- vector(mode = "list", length = n)
    dual_tol2_list <- vector(mode = "list", length = n)
    
    for (i in 1:n) {
      dual_resi2_list[[i]] <- matrix(0, nrow = p, ncol = q)
      dual_tol2_list[[i]] <- matrix(0, nrow = p, ncol = q)
      
      dual_resi2_list[[i]][,1] <- apply(as.matrix(V2_new[(1+(i-1)*p):(i*p), index2[,1] == 1]), MARGIN = 1, sum) -
        apply(as.matrix(V2_old[(1+(i-1)*p):(i*p), index2[,1] == 1]), MARGIN = 1, sum)
      
      dual_tol2_list[[i]][,1] <- apply(as.matrix(Lambda2_new[(1+(i-1)*p):(i*p), index2[,1] == 1]), MARGIN = 1, sum)
      
      for (k in 2:(q-1)) {
        dual_resi2_list[[i]][,k] <- apply(as.matrix(V2_new[(1+(i-1)*p):(i*p), index2[,1] == k]), MARGIN = 1, sum) -
          apply(as.matrix(V2_new[(1+(i-1)*p):(i*p), index2[,2] == k]), MARGIN = 1, sum) - 
          apply(as.matrix(V2_old[(1+(i-1)*p):(i*p), index2[,1] == k]), MARGIN = 1, sum) +
          apply(as.matrix(V2_old[(1+(i-1)*p):(i*p), index2[,2] == k]), MARGIN = 1, sum)
        
        dual_tol2_list[[i]][,k] <- apply(as.matrix(Lambda2_new[(1+(i-1)*p):(i*p), index2[,1] == k]), MARGIN = 1, sum) -
          apply(as.matrix(Lambda2_new[(1+(i-1)*p):(i*p), index2[,2] == k]), MARGIN = 1, sum) 
      }
      
      dual_resi2_list[[i]][,q] <- -apply(as.matrix(V2_new[(1+(i-1)*p):(i*p), index2[,2] == q]), MARGIN = 1, sum) +
        apply(as.matrix(V2_old[(1+(i-1)*p):(i*p), index2[,2] == q]), MARGIN = 1, sum)
      
      dual_tol2_list[[i]][,q] <- -apply(as.matrix(Lambda2_new[(1+(i-1)*p):(i*p), index2[,2] == q]), MARGIN = 1, sum)
      
      dual_resi2_list[[i]] <- as.vector(dual_resi2_list[[i]])
      dual_tol2_list[[i]] <- as.vector(dual_tol2_list[[i]])
    }
    
    dual_resi2_vec <- do.call("c", dual_resi2_list)
    dual_tol2_vec <- do.call("c", dual_tol2_list)
    dual_resi2 <- sqrt(sum(dual_resi2_vec^2))
    dual_tol2 <- sqrt(n*p*q)*eps_abs + eps_rel*sqrt(sum(dual_tol2_vec^2))
    
    
    stop_con <- pri_resi1 > pri_tol1 | pri_resi2 > pri_tol2 | dual_resi1 > dual_tol1 | dual_resi2 > dual_tol2
    
    print(iter)
    iter <- iter + 1
    Beta_old <- Beta_new
    V1_old <- V1_new
    V2_old <- V2_new
    Lambda1_old <- Lambda1_new
    Lambda2_old <- Lambda2_new
    
  }
  
  
  return(list(Beta = Beta_new, V1 = V1_new, V2 = V2_new, Lambda1 = Lambda1_new, Lambda2 = Lambda2_new, iter = iter))
}




